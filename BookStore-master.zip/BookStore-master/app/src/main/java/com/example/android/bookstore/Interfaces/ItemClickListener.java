package com.example.android.bookstore.Interfaces;

import android.view.View;

/**
 * Created by hblgdrl on 16.12.2017.
 */

public interface ItemClickListener {
    void OnClick(View view, int position, boolean islongClick);
}
