package com.example.android.bookstore;

import com.example.android.bookstore.Model.Customer;
import com.example.android.bookstore.Model.Owner;

/**
 * Created by hblgdrl on 17.12.2017.
 */

public class Common {
    public static Customer currentCustomer;
    public static Owner currentOwner;
    public static boolean isCustomer = false;
    public static final int PICK_IMAGE_REQUEST = 71;
    public static final String USER_KEY = "User";
    public static final String PWD_KEY = "Password";
    public static final String  LAST_KEY = "LastUser";
}
